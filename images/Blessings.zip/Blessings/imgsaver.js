cameraArray = [];
function saveAndDisplayImage(ImageOrder) {
    // Get the input element
    var input = ImageOrder === 'FirstImage' ? document.getElementById('imageInput') : document.getElementById('SignatureFile');

    // Ensure a file is selected
    if (input.files && input.files[0]) {
        var reader = new FileReader();
       
      
        reader.onload = function (e) {
            var imageDataUrl = e.target.result;
            var displayedImage = document.getElementById('ImageViewer');
            displayedImage.src = imageDataUrl;


        }

        reader.readAsDataURL(input.files[0])

    }
}

function onSubmit() {
    // event.preventDefault();

    var cameraName = document.getElementById("name").value.trim();
    var cameraPrice = document.getElementById("price").value.trim();
    var cameraDescription = document.getElementById("description").value.trim();
    var cameraColor = document.getElementById("color").value.trim();

    var imageData = document.getElementById('ImageViewer').src;  
      var cameraObject = {
        name: cameraName,
        price: cameraPrice,
        description: cameraDescription,
        color: cameraColor,
        image: imageData
    };

    // var cameraArray = JSON.parse(localStorage.getItem("cameraArray")) || [];

  
    cameraArray.push(cameraObject);

    localStorage.setItem("cameraArray", JSON.stringify(cameraArray));
alert("Successfully Saved")
    // Go to the next page
   // 
}

function onRedirect(){
    window.location.href = 'imagesaver.html';
}

function displayImageAndInfo() {
    var cameraArray = JSON.parse(localStorage.getItem("cameraArray")) || [];

    if (cameraArray.length > 0) {
        var lastIndex = cameraArray.length - 1;
        var currentImage = cameraArray[0].image;
        var cameraName = cameraArray[0].name;
        var cameraPrice = cameraArray[0].price;
        var cameraDescription = cameraArray[0].description;
        var cameraColor = cameraArray[0].color;

        var displayedImage = document.getElementById('ImageViewer');
        displayedImage.src = currentImage; 

        document.getElementById('Name').innerText = 'Name: ' + cameraName;
        document.getElementById('Price').innerText = 'Price: ' + cameraPrice;
        document.getElementById('Description').innerText = 'Description: ' + cameraDescription;
        document.getElementById('Color').innerText = 'Color: ' + cameraColor;
    }
}
window.onload = function () {
    displayImageAndInfo();
};







