function displayImageAndInfo(currentIndex) {
 var cameraArray = JSON.parse(localStorage.getItem("cameraArray")) || [];

 if (cameraArray.length > 0) {
   
     var currentImage = cameraArray[currentIndex].image;
     var cameraName = cameraArray[currentIndex].name;
     var cameraPrice = cameraArray[currentIndex].price;
     var cameraDescription = cameraArray[currentIndex].description;
     var cameraColor = cameraArray[currentIndex].color;

     var displayedImage = document.getElementById('ImageViewer');
     displayedImage.src = currentImage; 

     document.getElementById('Name').innerText = 'Name: ' + cameraName;
     document.getElementById('Price').innerText = 'Price: ' + cameraPrice;
     document.getElementById('Description').innerText = 'Description: ' + cameraDescription;
     document.getElementById('Color').innerText = 'Color: ' + cameraColor;
 }
}
window.onload = function () {
 displayImageAndInfo(0);

};
function onNext() {
 var currentIndex = parseInt(localStorage.getItem('currentIndex')) || 0;
 var cameraArray = JSON.parse(localStorage.getItem("cameraArray")) || [];

 if (currentIndex < cameraArray.length - 1) {
     currentIndex++;
     displayImageAndInfo(currentIndex);
     sessionStorage.setItem('currentIndex', currentIndex);
 }
}

function onPrevious() {
 var currentIndex = parseInt(localStorage.getItem('currentIndex')) || 0;
 var cameraArray = JSON.parse(localStorage.getItem("cameraArray")) || [];

 if (currentIndex > 0) {
     currentIndex--;
     displayImageAndInfo(currentIndex);
     sessionStorage.setItem('currentIndex', currentIndex);
 }
}

